<?php 
// Add-on: Color Palette
// https://github.com/7studio/acf-color-palette

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

include( ACFTCP_Core::$plugin_path . 'pro/render/radio.php' );
